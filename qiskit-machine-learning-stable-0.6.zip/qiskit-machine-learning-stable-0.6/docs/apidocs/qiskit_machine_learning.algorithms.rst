.. _qiskit-machine-learning-algorithms:

.. automodule:: qiskit_machine_learning.algorithms
   :no-members:
   :no-inherited-members:
   :no-special-members:

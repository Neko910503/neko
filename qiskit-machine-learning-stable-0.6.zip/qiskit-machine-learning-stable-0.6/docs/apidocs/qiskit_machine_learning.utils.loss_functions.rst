﻿.. _qiskit-machine-learning-utils-loss_functions:

.. automodule:: qiskit_machine_learning.utils.loss_functions
   :no-members:
   :no-inherited-members:
   :no-special-members:

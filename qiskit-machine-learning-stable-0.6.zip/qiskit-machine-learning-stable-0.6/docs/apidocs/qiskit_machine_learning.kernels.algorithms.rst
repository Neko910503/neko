﻿.. _qiskit-machine-learning-kernels-algorithms:

.. automodule:: qiskit_machine_learning.kernels.algorithms
   :no-members:
   :no-inherited-members:
   :no-special-members:

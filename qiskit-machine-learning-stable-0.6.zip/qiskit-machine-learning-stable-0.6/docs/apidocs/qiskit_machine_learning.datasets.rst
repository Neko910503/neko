.. _qiskit-machine-learning-datasets:

.. automodule:: qiskit_machine_learning.datasets
   :no-members:
   :no-inherited-members:
   :no-special-members:
